﻿using UnityEngine;
using System.Collections;

public enum ENTITY_STATE  { IDLE = 0, MOVE, ATTACK, HIT, CASTING, DIE, }
public enum ENTITY_CLASS { NOOB = 0, MAGE, MARRIOR, ARCHER, }
public class Constants : MonoBehaviour { }